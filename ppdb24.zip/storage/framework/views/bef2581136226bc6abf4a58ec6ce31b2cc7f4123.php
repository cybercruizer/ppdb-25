<html>
    <head>
        <title>Laporan Pembayaran</title>
    </head>
    <body>
        <h2>Laporan Pembayaran Daftar Ulang</h2>
        <h2>PPDB 2024/ 2025</h2>
        <table>
            <tr>
                <td>No</td>
                <td>Nama</td>
                <td>No Pendaftaran</td>
                <td>Jurusan</td>
                <td>Nominal Bayar</td>
                <td>Tgl Bayar</td>
            </tr>
            <?php $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e(strtoupper($p->siswa->nama)); ?></td>
                    <td><?php echo e($p->siswa->no_pendaf); ?></td>
                    <td><?php echo e($p->siswa->jurusan); ?></td>
                    <td><p class="rupiah"><?php echo e($p->nominal); ?></p></td>
                    <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d/m/Y')); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script>
            $(document).ready(function() {
                    $('.rupiah').mask('#.##0', {
                        reverse: true
                    });
                });
        </script>
    </body>


</html>
<?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/pembayaran/laporan.blade.php ENDPATH**/ ?>