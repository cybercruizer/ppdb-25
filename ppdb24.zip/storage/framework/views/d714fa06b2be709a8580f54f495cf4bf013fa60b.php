<table>
<tr>
    <td>ID</td>
    <td>Nama</td>
    <td>Tagihan</td>
</tr>
<?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td> <?php echo e($siswa->id); ?></td>
    <td><?php echo e($siswa->nama); ?></td>
    <td><?php echo e($siswa->tagihan->id ?? 'kosong'); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/pembayaran/cek.blade.php ENDPATH**/ ?>