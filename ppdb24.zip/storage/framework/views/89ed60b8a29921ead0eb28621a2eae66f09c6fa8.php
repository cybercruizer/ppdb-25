<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>EDIT SISWA : <?php echo e($siswa->nama); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('pendaftar.update', $siswa->id)); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('PUT'); ?>
<div class="container">
    <div class="card" style="margin-top: 20px;">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="card-header bg-info">
            <h5 class="text-white mb-0">DATA CALON SISWA</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive border rounded">
                <table class="table table-striped table-borderless">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Nama lengkap</td>
                            <td><input class="border rounded-pill shadow-sm form-control-lg" type="text" name="nama" style="width: 100%;" value="<?php echo e($siswa->nama); ?>"></td>
                        </tr>
                        <tr>
                            <td>Nomor pendaftaran</td>
                            <td><input class="border rounded-pill shadow-sm form-control-lg" type="text" name="no_pendaf" style="width: 100%;" value="<?php echo e($siswa->no_pendaf); ?>"></td>
                        </tr>
                        <tr>
                            <td>Jurusan</td>
                            <td><select class="border rounded-pill shadow-sm form-control-lg" name="jurusan">
                                    <option value="TKJ" <?php echo e($siswa->jurusan == 'TKJ' ? 'selected' : ''); ?>>Teknik Komputer dan Jaringan</option>
                                    <option value="TPM"<?php echo e($siswa->jurusan == 'TPM' ? 'selected' : ''); ?>>Teknik Pemesainan</option>
                                    <option value="TITL" <?php echo e($siswa->jurusan == 'TITL' ? 'selected' : ''); ?>>Teknik Instalasi Tenaga Listrik</option>
                                    <option value="TKR" <?php echo e($siswa->jurusan == 'TKR' ? 'selected' : ''); ?>>Teknik Kendaraan Ringan</option>
                                    <option value="TSM" <?php echo e($siswa->jurusan == 'TSM' ? 'selected' : ''); ?>>Teknik Sepeda Motor</option>
                                    <option value="PHT" <?php echo e($siswa->jurusan == 'PHT' ? 'selected' : ''); ?>>Perhotelan</option>
                                    <option value="KUL" <?php echo e($siswa->jurusan == 'KUL' ? 'selected' : ''); ?>>Kuliner</option>
                                </select></td>
                        </tr>
                        
                        <tr>
                            <td>Tempat &amp; tanggal lahir</td>
                            <td><input value="<?php echo e($siswa->tempat_lahir); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="tempat_lahir" style="width: 300px;" placeholder="Kabupaten/ Kota">&nbsp;&nbsp;
                                <input class="border rounded-pill form-control-lg" type="date" name="tgl_lahir" value="<?php echo e($siswa->tgl_lahir); ?>">
                            </td>
                        </tr>
                        <tr>
                            <td>Jenis kelamin</td>
                            <td><select class="border rounded shadow-sm form-control-lg" name="jenis_kelamin">
                                    <option value="L" <?php echo e($siswa->jenis_kelamin == 'L' ? 'selected' : ''); ?>>Laki- Laki</option>
                                    <option value="P" <?php echo e($siswa->jenis_kelamin == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                                </select></td>
                        </tr>
                        
                        <tr style="height: 150px">
                            <td>Alamat lengkap</td>
                            <td><textarea class="shadow-sm form-control-lg h-100" style="width: 100%;" name="alamat" placeholder="Nama Jalan, RT, RW, Dusun, Desa, Kecamatan" rows="3"><?php echo e($siswa->alamat); ?></textarea></td>
                        </tr>
                        <tr>
                            <td>Asal Sekolah (SMP)</td>
                            <td><input value="<?php echo e($siswa->asal_sekolah); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="asal_sekolah" style="width: 100%;"></td>
                        </tr>
                        
                        <tr>
                            <td>Nomor Telp / HP</td>
                            <td><input value="<?php echo e($siswa->no_telp); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="no_telp" style="width: 100%;"></td>
                        </tr>
                        <tr>
                            <td>Nama rekomendator</td>
                            <td><input value="<?php echo e($siswa->rekomendator); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="rekomendator" style="width: 100%;"></td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
            <br><br>
            <div class="card">
                <div class="card-header bg-info">
                    <h5 class="mb-0 text-white">DATA ORANG TUA/ WALI</h5>
                </div>
                <div class="card-body" style="margin-bottom: 0;">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Nama ayah</td>
                                    <td><input value="<?php echo e($ortu->nama_ayah); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="nama_ayah" style="width: 100%;"></td>
                                </tr>
                                <tr>
                                    <td>Nama ibu</td>
                                    <td><input value="<?php echo e($ortu->nama_ibu); ?>"class="border rounded-pill shadow-sm form-control-lg" type="text" name="nama_ibu" style="width: 100%;"></td>
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <p style="margin-top: 20px;">Pastikan data sudah terisi dengan lengkap, kemudian klik tombol "KIRIM FORM" di bawah ini :</p>
            <button class="btn btn-primary btn-lg font-weight-bold border rounded shadow-sm" type="submit" style="margin-top: 1px;"><i class="fas fa-paper-plane"></i>&nbsp;KIRIM FORM</button>
        </div>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/edit.blade.php ENDPATH**/ ?>