<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Histori Pembayaran</h1>

        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Siswa</th>
                    <th>Tagihan</th>
                    <th>Tahun</th>
                    <th>Nominal</th>
                    <th>Status Pembayaran</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $historiPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($pembayaran->siswa->nama); ?></td>
                    <td><?php echo e($pembayaran->tagihan->nama_tagihan); ?></td>
                    <td><?php echo e($pembayaran->tahun->tahun); ?></td>
                    <td><?php echo e($pembayaran->nominal); ?></td>
                    <td>
                        <?php if($pembayaran->nominal >= $pembayaran->tagihan->nominal): ?>
                            Lunas
                        <?php else: ?>
                            Kekurangan: <?php echo e($pembayaran->tagihan->nominal - $pembayaran->nominal); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/pembayaran/index.blade.php ENDPATH**/ ?>