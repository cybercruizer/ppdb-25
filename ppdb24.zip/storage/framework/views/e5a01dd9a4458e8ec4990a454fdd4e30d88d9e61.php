<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>EDIT SISWA : <?php echo e($siswa->nama); ?></h1>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<script>
		window.onload=passwordCheck;
		function passwordCheck()
		{
    		var password = prompt("Masukkan PIN pengaman");
    		if (password !== "4321") {
        		passwordCheck();
    		}
		}
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('pendaftar.update', $siswa->id)); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('PUT'); ?>
<div class="container">
    <div class="card" style="margin-top: 20px;">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="card-header bg-info">
            <h5 class="text-white mb-0">DATA CALON SISWA</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive border rounded">
                <table class="table table-striped table-borderless">
                    <tbody>
                        <tr>
                            <td>Nama lengkap</td>
                            <td><input class="border rounded-pill shadow-sm form-control-lg" type="text" name="nama" style="width: 100%;" value="<?php echo e($siswa->nama); ?>"></td>
                        </tr>
                        <tr>
                            <td>Nomor pendaftaran</td>
                            <td><input class="border rounded-pill shadow-sm form-control-lg" type="text" name="no_pendaf" style="width: 100%;" value="<?php echo e($siswa->no_pendaf); ?>"></td>
                        </tr>
                        <tr>
                            <td>Jurusan</td>
                            <td><select class="border rounded-pill shadow-sm form-control-lg" name="jurusan">
                                    <option value="TKJ" <?php echo e($siswa->jurusan == 'TKJ' ? 'selected' : ''); ?>>Teknik Komputer dan Jaringan</option>
                                    <option value="TPM"<?php echo e($siswa->jurusan == 'TPM' ? 'selected' : ''); ?>>Teknik Pemesainan</option>
                                    <option value="TITL" <?php echo e($siswa->jurusan == 'TITL' ? 'selected' : ''); ?>>Teknik Instalasi Tenaga Listrik</option>
                                    <option value="TKR" <?php echo e($siswa->jurusan == 'TKR' ? 'selected' : ''); ?>>Teknik Kendaraan Ringan</option>
                                    <option value="TSM" <?php echo e($siswa->jurusan == 'TSM' ? 'selected' : ''); ?>>Teknik Sepeda Motor</option>
                                    <option value="PHT" <?php echo e($siswa->jurusan == 'PHT' ? 'selected' : ''); ?>>Perhotelan</option>
                                    <option value="KUL" <?php echo e($siswa->jurusan == 'KUL' ? 'selected' : ''); ?>>Kuliner</option>
                                </select></td>
                        </tr>
                        <tr>
                            <td>Pondok</td>
                            <td><select class="border rounded-pill shadow-sm form-control-lg" name="pondok">
                                    <option value="0" <?php echo e($siswa->pondok == '0' ? 'selected' : ''); ?>>Tidak</option>
                                    <option value="1" <?php echo e($siswa->pondok == '1' ? 'selected' : ''); ?>>Mondok</option>
                                </select>
                            </td>
                        </tr>
                        
                        <tr>
                            <td>Tempat &amp; tanggal lahir</td>
                            <td><input value="<?php echo e($siswa->tempat_lahir); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="tempat_lahir" style="width: 300px;" placeholder="Kabupaten/ Kota">&nbsp;&nbsp;
                                <input class="border rounded-pill form-control-lg" type="date" name="tgl_lahir" value="<?php echo e($siswa->tgl_lahir); ?>">
                            </td>
                        </tr>
                        <tr>
                            <td>Jenis kelamin</td>
                            <td><select class="border rounded shadow-sm form-control-lg" name="jenis_kelamin">
                                    <option value="L" <?php echo e($siswa->jenis_kelamin == 'L' ? 'selected' : ''); ?>>Laki- Laki</option>
                                    <option value="P" <?php echo e($siswa->jenis_kelamin == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>
                            </td>
                        </tr>
                        
                        <tr style="height: 150px">
                            <td>Alamat lengkap</td>
                            <td><textarea class="shadow-sm form-control-lg h-100" style="width: 100%;" name="alamat" placeholder="Nama Jalan, RT, RW, Dusun, Desa, Kecamatan" rows="3"><?php echo e($siswa->alamat); ?></textarea></td>
                        </tr>
                        <tr>
                            <td>Asal Sekolah (SMP)</td>
                            <td><input value="<?php echo e($siswa->asal_sekolah); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="asal_sekolah" style="width: 100%;"></td>
                        </tr>
                        
                        <tr>
                            <td>Nomor Telp / HP</td>
                            <td><input value="<?php echo e($siswa->no_telp); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="no_telp" style="width: 100%;"></td>
                        </tr>
                        <tr>
                            <td>Nama rekomendator (siswa)</td>
                            <td><input placeholder="Contoh: Yoga (X TSM 2)" value="<?php echo e($siswa->rekomendator); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="rekomendator" style="width: 100%;"></td>
                        </tr>
                        <tr>
                            <td>Nama rekomendator (GuKar)</td>
                            <td>
                                
                                <?php echo Form::select('guru_id', $guru, $siswa->guru_id, ['class'=>'form-control select2','placeholder'=>'Pilih nama guru']); ?>

                            </td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
            <br><br>
            <div class="card">
                <div class="card-header bg-info">
                    <h5 class="mb-0 text-white">DATA ORANG TUA/ WALI</h5>
                </div>
                <div class="card-body" style="margin-bottom: 0;">
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>Nama ayah</td>
                                    <td><input value="<?php echo e($ortu->nama_ayah??''); ?>" class="border rounded-pill shadow-sm form-control-lg" type="text" name="nama_ayah" style="width: 100%;"></td>
                                </tr>
                                <tr>
                                    <td>Nama ibu</td>
                                    <td><input value="<?php echo e($ortu->nama_ibu??''); ?>"class="border rounded-pill shadow-sm form-control-lg" type="text" name="nama_ibu" style="width: 100%;"></td>
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header bg-info">
                    <h5 class="mb-0 text-white">DATA KHUSUS BEASISWA</h5>
                </div>
                <div class="card-body" style="margin-bottom: 0;">
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>Kategori Pendaftar</td>
                                    <td>
                                        <select class="border rounded shadow-sm form-control-lg" name="kategori">
                                            <option value="REG" <?php echo e($siswa->kategori == 'REG' ? 'selected' : ''); ?>>Reguler</option>
                                            <option value="AP50" <?php echo e($siswa->kategori == 'AP50' ? 'selected' : ''); ?>>AP 50%</option>
                                            <option value="AP100" <?php echo e($siswa->kategori == 'AP100' ? 'selected' : ''); ?>>AP 100%</option>
                                            <option value="KB" <?php echo e($siswa->kategori == 'KB' ? 'selected' : ''); ?>>Kakak beradik beda tingkat</option>
                                            <option value="KB2" <?php echo e($siswa->kategori == 'KB2' ? 'selected' : ''); ?>>Kakak beradik masuk berbarengan</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Tagihan Daftar Ulang</td>
                                    <td>
                                        <select class="border rounded shadow-sm form-control-lg" name="tagihan_du">
                                            <option value="1000000" <?php echo e($siswa->tagihan->nominal == 1000000 ? 'selected' : ''); ?>>1.000.000 (Gel-1)</option>
                                            <option value="1300000" <?php echo e($siswa->tagihan->nominal == 1300000 ? 'selected' : ''); ?>>1.300.000 (Pondok)</option>
                                            <option value="1500000" <?php echo e($siswa->tagihan->nominal == 1500000 ? 'selected' : ''); ?>>1.500.000 (Gel-2)</option>
                                            <option value="2000000" <?php echo e($siswa->tagihan->nominal == 2000000 ? 'selected' : ''); ?>>2.000.000 (Gel-3)</option>
                                        </select>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <p style="margin-top: 20px;">Pastikan data sudah terisi dengan lengkap, kemudian klik tombol "KIRIM FORM" di bawah ini :</p>
            <button class="btn btn-primary btn-lg font-weight-bold border rounded shadow-sm" type="submit" style="margin-top: 1px;"><i class="fas fa-paper-plane"></i>&nbsp;KIRIM FORM</button>
        </div>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    <link href="/vendor/select2/select2.css" rel="stylesheet" />
    <link href="/vendor/select2/select2-bootstrap4.css" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script src="/vendor/select2/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                theme: 'bootstrap4',
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/pendaftar_edit.blade.php ENDPATH**/ ?>