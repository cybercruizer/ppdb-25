<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::resolve(['theme' => 'success','title' => 'Pendaftar per Jurusan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="row">
            <div class="col-md-3">
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'SEMUA PENDAFTAR','text' => ''.e($siswadu).' / '.e($siswa->count()).'','icon' => 'fas fa-lg fa-users text-light','iconTheme' => 'gradient-purple'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3">
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'PERHOTELAN','text' => ''.e($data[6]['sub_value']).' / '.e($data[6]['value']).'','icon' => 'fas fa-lg fa-hotel text-light','iconTheme' => 'gradient-orange'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3">
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'KULINER','text' => ''.e($data[5]['sub_value']).' / '.e($data[5]['value']).'','icon' => 'fas fa-lg fa-utensils text-light','iconTheme' => 'gradient-pink'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3">
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'TPM','text' => ''.e($data[1]['sub_value']).' / '.e($data[1]['value']).'','icon' => 'fas fa-lg fa-cogs text-light','iconTheme' => 'gradient-red'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="row">
                <div class="col-md-3">
                    <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'TKR','text' => ''.e($data[2]['sub_value']).' / '.e($data[2]['value']).'','icon' => 'fas fa-lg fa-car-side text-light','iconTheme' => 'gradient-green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
                </div>
                <div class="col-md-3">
                    <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'TKJ','text' => ''.e($data[0]['sub_value']).' / '.e($data[0]['value']).'','icon' => 'fas fa-lg fa-desktop text-light','iconTheme' => 'gradient-blue'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
                </div>
                <div class="col-md-3">
                    <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'TSM','text' => ''.e($data[3]['sub_value']).' / '.e($data[3]['value']).'','icon' => 'fas fa-lg fa-motorcycle text-light','iconTheme' => 'gradient-orange'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
                </div>
                <div class="col-md-3">
                    <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'TITL','text' => ''.e($data[4]['sub_value']).' / '.e($data[4]['value']).'','icon' => 'fas fa-lg fa-bolt text-light','iconTheme' => 'gradient-yellow'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
                </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'Aksi Peduli','text' => ''.e($ap).'','icon' => 'fas fa-lg fa-gift text-light','iconTheme' => 'gradient-green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            </div>
            <div class="col-md-6">
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::resolve(['title' => 'Pondok','text' => ''.e($pondok).'','icon' => 'fas fa-lg fa-building text-light','iconTheme' => 'gradient-blue'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            </div>
    </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::resolve(['theme' => 'info','title' => 'Grafik Pendaftar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="container">
            <canvas id="myChart" width="400" height="200"></canvas>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>


    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var ctx = document.getElementById('myChart').getContext('2d');
            var data = <?php echo json_encode($data, 15, 512) ?>;

            var labels = data.map(item => item.label);
            var values = data.map(item => item.value);
            var sub_values = data.map(item => item.sub_value);

            var chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Pendaftar',
                        data: values,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }, {
                        label: 'Daftar Ulang',
                        data: sub_values,
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
         $(document).ready(function() {
            $('.rupiah').mask("#.##0", {
                reverse: true
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/home.blade.php ENDPATH**/ ?>