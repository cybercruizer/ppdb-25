<?php $__env->startSection('title', 'History Pembayaran'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Histori Pembayaran</h1>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <form action="<?php echo e(route('pembayaran.history')); ?>" method="GET">
            <div class="row align-items-center">
                <div class="form-group col-lg-4">
                    <label for="start_date">Tgl Awal:</label>
                    <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                </div>
                <div class="form-group col-lg-4">
                    <label for="end_date">Tgl Akhir:</label>
                    <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo e($endDate); ?>">
                </div>
                <div class="col-lg-4">
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-search"></i> Cari Per Tanggal</button>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-4">
                    <a href="<?php echo e(route('admin.history.laporan')); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-success">Eksport Laporan</a>

                </div>
            </div>

        </form>
    </div>
<div class="card-body">
<div class="table-responsive">
    <table class="table table-hover text-nowrap">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Siswa</th>
                <th>Tagihan</th>
                <th>Nominal</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $historiPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($historiPembayaran->firstItem() + $pembayaran); ?></td>
                <td><?php echo e(strtoupper($p->siswa->nama)); ?></td>
                <td><?php echo e($p->tagihan->nama_tagihan); ?></td>
                <td><p class="rupiah"><?php echo e($p->nominal); ?></p></td>
                <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d/m/Y')); ?></td>
                <td><a href="hapus/<?php echo e($p->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin menghapus data pembayaran untuk nama <?php echo e($p->siswa->nama); ?> ?')"><i class="fas fa-trash-alt"></i></a></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
<div class="card-footer clearfix">
    <ul class="pagination pagination m-0 float-right">
        <?php echo $historiPembayaran->links(); ?>

    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    window.deleteConfirm = function (e) {
    e.preventDefault();
    var form = e.target.form;
    swal({
        title: "Yakin akan menghapus data ini?",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
            form.submit();
        }
      });
    }
</script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
    $(document).ready(function() {
            $('.rupiah').mask('#.##0', {
                reverse: true
            });
        });
</script>
<script> console.log('halaman profil'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/pembayaran/history.blade.php ENDPATH**/ ?>