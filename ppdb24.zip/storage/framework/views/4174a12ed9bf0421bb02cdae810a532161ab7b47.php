
    <html>
        <head>
            <title><?php echo e($title); ?></title>
        </head>
    <table class="table table-hover text-nowrap">
        <thead class="thead-dark">
            <tr>
                <th class="col-sm-1">No</th>
                <th class="col-sm-2">No Pendaft</th>
                <th class="col-sm-2">Jurusan</th>
                <th class="col-sm-3">Nama</th>
                <th class="col-sm-2">No Telp</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($siswa) && $siswa->count()): ?>
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($s->no_pendaf); ?></td>
                    <td><?php echo e($s->jurusan); ?></td>
                    <td><?php echo e($s->nama); ?></td>
                    <td><?php echo e($s->no_telp); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Tidak ada data</td>
                </tr>

            <?php endif; ?>
        </tbody>
    </table>
    </html><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/pendaftar_all.blade.php ENDPATH**/ ?>