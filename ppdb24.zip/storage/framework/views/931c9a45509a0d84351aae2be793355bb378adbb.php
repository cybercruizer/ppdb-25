<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($title); ?></h1>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <a href="/admin/pendaftar/export/excel" class="btn btn-labeled btn-success my-3" target="_blank"><span class="btn-label"><i class="fa fa-arrow-down"></i></span> EXPORT KE EXCEL</a>
        <div class="card-tools">
            <form action="<?php echo e(route('caripendaftar')); ?>" method="GET">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Cari nama .." name="cari">
                <?php echo e(csrf_field()); ?>

                <div class="input-group-append">
                  <button class="btn btn-secondary" type="submit">
                    <i class="fa fa-search"></i>
                  </button>
                </div>
              </div>
            </form>
        </div>
    </div>
<div class="card-body">
<div class="table-responsive">
    <table class="table table-hover text-nowrap">
        <thead class="thead-dark">
            <tr>
                <th style="width: 30px">No</th>
                <th style="width: 80px">No Pendaft</th>
                <th style="width: 50px">Jurusan</th>
                <th class="col-sm-3">Nama</th>
                <th class="col-sm-2">No Telp</th>
                <th class="col-sm-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($siswa) && $siswa->count()): ?>
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($siswa->firstItem() + $key); ?></td>
                    <td><?php echo e($s->no_pendaf); ?></td>
                    <td><?php echo e($s->jurusan); ?></td>
                    <td><?php echo e($s->nama); ?></td>
                    <td><?php echo e($s->no_telp); ?></td>
                    <td><a class="btn btn-info btn-sm" role="button" href="/pendaftar/cetak/<?php echo e($s->id); ?>"><i class="fas fa-print"></i></a>
                        <a class="btn btn-primary btn-sm" role="button" href="/admin/pendaftar/edit/<?php echo e($s->id); ?>"><i class="fas fa-pencil-alt"></i></a>
                        <a href="/admin/pendaftar/hapus/<?php echo e($s->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin menghapus data atas nama <?php echo e($s->nama); ?> ?')"><i class="far fa-trash-alt"></i></a>
                        <a class="btn btn-success btn-sm" role="button" href="https://wa.me/+62<?php echo e($s->no_telp); ?>">WA</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Tidak ada data</td>
                </tr>

            <?php endif; ?>
        </tbody>
    </table>
</div>
</div>
<div class="card-footer clearfix">
    <ul class="pagination pagination m-0 float-right">
        <?php echo $siswa->links(); ?>

    </ul>
</div>
</div>
<script type="text/javascript">
    window.deleteConfirm = function (e) {
    e.preventDefault();
    var form = e.target.form;
    swal({
        title: "Are you sure you want to delete?",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
            form.submit();
        }
      });
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .btn-label {
	position: relative;
	left: -12px;
	display: inline-block;
	padding: 6px 12px;
	background: rgba(0, 0, 0, 0.15);
	border-radius: 3px 0 0 3px;
}

.btn-labeled {
	padding-top: 0;
	padding-bottom: 0;
}

.btn {
	margin-bottom: 10px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/ap_index.blade.php ENDPATH**/ ?>