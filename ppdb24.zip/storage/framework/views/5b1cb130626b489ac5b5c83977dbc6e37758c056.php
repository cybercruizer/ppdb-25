<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Input Pembayaran</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-tools my-3 mr-3">
    <!-- Form untuk pencarian siswa -->
            <form action="<?php echo e(route('admin.pembayaran')); ?>" method="GET">
                <div class="input-group mb-3 mr-3">
                    <input type="text" name="search" class="form-control" placeholder="Pencarian siswa" aria-label="Pencarian siswa" aria-describedby="basic-addon2 value="<?php echo e(request()->query('search')); ?>">
                    <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </div>
            </form>
        </div>
    <a href="<?php echo e(route('pembayaran.exportExcel')); ?>" class="btn btn-labeled btn-success my-3" target="_blank"><span class="btn-label"><i class="fa fa-arrow-down"></i></span> EXPORT DATA KE EXCEL</a>
    </div>
    <div class="card-body">
    <!-- Tabel untuk menampilkan daftar siswa -->
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>No Pendaft</th>
                <th>Jurusan</th>
                <th>Tagihan</th>
                <th>Ket.</th>
                <th>WA</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($siswaList->firstItem() + $siswa); ?></td>
                <td><?php echo e(strToUpper($s->nama)); ?></td>
                <td><?php echo e($s->no_pendaf); ?></td>
                <td><?php echo e($s->jurusan); ?></td>
                <td><span class="rupiah"><?php echo e($s->tagihan->nominal); ?></span></td>
                <td>
                    <?php if(!empty($s)): ?>
                        <?php if($s->total_pembayaran >= $s->tagihan->nominal): ?>
                            <span class="badge badge-success">Lunas</span>
                        <?php else: ?>
                            <p class="text-danger">Kurang: <span class="rupiah"><?php echo e($s->tagihan->nominal - $s->total_pembayaran); ?></span></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="https://wa.me/62<?php echo e($s->no_telp); ?>" class="btn btn-success" target="_blank">WA</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <!-- Tampilkan pagination links -->
    <div class="card-footer clearfix">
        <ul class="pagination pagination m-0 float-right">
            <?php echo $siswaList->links(); ?>

        </ul>
    </div>

    <?php $__currentLoopData = $siswaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="inputPembayaranModal<?php echo e($siswa->id); ?>" tabindex="-1" role="dialog" aria-labelledby="inputPembayaranModalLabel<?php echo e($siswa->id); ?>" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inputPembayaranModalLabel<?php echo e($siswa->id); ?>">Input Pembayaran untuk <?php echo e($siswa->nama); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Form untuk input pembayaran -->
                    <form action="<?php echo e(route('pembayaran.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="siswa_id" value="<?php echo e($siswa->id); ?>">
                        <input type="hidden" name="tagihan_id" value="<?php echo e($siswa->tagihan->id); ?>">
                        
                        <label for="tagihan">Jumlah Tagihan:</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1">Rp </span>
                            </div>

                            <input id="tagihan" name="tagihan" type="text" class="form-control rupiah" aria-label="Nominal" aria-describedby="basic-addon1" value="<?php echo e($siswa->tagihan->nominal ?? '0'); ?>" disabled>
                        </div>
                        <label for="kekurangan">Kekurangan:</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1">Rp </span>
                            </div>

                            <input id="kekurangan" name="kekurangan" type="text" class="form-control rupiah" aria-label="Nominal" aria-describedby="basic-addon1" value="<?php echo e($siswa->tagihan->nominal - $siswa->total_pembayaran); ?>" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label for="nominal">Nominal Pembayaran:</label>
                            <input type="text" name="nominal" id="nominal" class="form-control rupiah">
                        </div>
                        <button type="text" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
    $(document).ready(function() {
            $('.rupiah').mask('#.##0', {
                reverse: true
            });
        });
</script>
<script> console.log('halaman pembayaran'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ppdb24/htdocs/ppdb24.smkmuhmungkid.sch.id/resources/views/pembayaran/admin_list.blade.php ENDPATH**/ ?>