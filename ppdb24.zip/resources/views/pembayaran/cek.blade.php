<table>
<tr>
    <td>ID</td>
    <td>Nama</td>
    <td>Tagihan</td>
</tr>
@foreach ($siswas as $siswa)
<tr>
    <td> {{ $siswa->id }}</td>
    <td>{{ $siswa->nama }}</td>
    <td>{{ $siswa->tagihan->id ?? 'kosong' }}</td>
</tr>
@endforeach
</table>
